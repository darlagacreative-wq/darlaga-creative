DARLAGA CREATIVE — FREE WEBSITE PUBLISHING

Your website is ready as index.html. To publish it free using GitHub Pages from your iPhone:

1. Open Safari and go to https://github.com/ and create/sign in to an account.
2. Create a new repository named: darlaga-creative
3. Set it to Public. You can leave “Add a README” unchecked, then create the repository.
4. On the repository page, tap Add file → Upload files.
5. Upload the file named index.html from this package. If your phone downloads this package as a ZIP, unzip it first in the Files app, then upload index.html.
6. Commit the upload.
7. In the repository, open Settings → Pages.
8. Under “Build and deployment”, choose “Deploy from a branch”. Select branch “main” and folder “/(root)”, then Save.
9. Wait a few minutes. GitHub Pages will show your public website address in Settings → Pages. It usually looks like https://YOUR-USERNAME.github.io/darlaga-creative/ .
10. Open the published link on your phone and test the page and contact form.

IMPORTANT:
- The contact form prepares an email addressed to darlagacreative@gmail.com; it does not collect or store form submissions.
- The website is not live until you complete the steps above.
- Replace any sample designs with your own original work. Don't claim sample concepts are paid client work.
- Confirm the package, price, deadline, and payment terms with each customer before starting.
